// Copyright (c) 2024, Muhammad Usman and contributors
// For license information, please see license.txt

frappe.ui.form.on('Facebook Lead Integration', {
	// refresh: function(frm) {

	// }
});
