# Copyright (c) 2024, Muhammad Usman and Contributors
# See license.txt

# import frappe
import unittest

class TestFacebookLeadIntegration(unittest.TestCase):
	pass
