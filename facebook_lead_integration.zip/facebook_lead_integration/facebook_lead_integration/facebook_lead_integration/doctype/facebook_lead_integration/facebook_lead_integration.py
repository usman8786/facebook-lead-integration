# Copyright (c) 2024, Muhammad Usman and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class FacebookLeadIntegration(Document):
	pass
