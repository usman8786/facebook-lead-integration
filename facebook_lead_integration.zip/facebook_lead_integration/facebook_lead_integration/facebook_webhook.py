# Copyright (c) 2022, Muhammad Usman, Frappe Technologies and contributors
# For license information, please see license.txt

import frappe
import json
import requests
from werkzeug.wrappers import Response
from datetime import datetime

@frappe.whitelist(allow_guest=True)
def facebook_lead():
    # Handle GET request from Facebook for webhook verification
    if frappe.local.request.method == 'GET':
        challenge = frappe.request.args.get('hub.challenge')
        mode = frappe.request.args.get('hub.mode')
        fb_verify_token = frappe.request.args.get('hub.verify_token')
        verify_token = frappe.db.get_single_value("Facebook Lead Integration", "verify_token")

        # Check if mode is subscribe and verify token matches
        if mode == 'subscribe' and fb_verify_token == verify_token:  # Replace with your verify token
            return Response(challenge, status=200, content_type="text/plain")
        else:
            return Response('Invalid verify token or mode', status=403, content_type="text/plain")


    # Handle POST request from Facebook for receiving lead data
    if frappe.local.request.method == 'POST':
        try:
            lead_data = json.loads(frappe.request.data.decode('utf-8'))
            frappe.log_error(lead_data, 'Lead Received From Facebook')

            create_lead(lead_data)
            
            # Log success and return proper response
            return Response(json.dumps({"status": "success", "message": "Lead created successfully"}), status=200, content_type="application/json")
        except Exception as e:
            frappe.log_error(frappe.get_traceback(), "Facebook Lead Error")
            return Response(json.dumps({"status": "error", "message": str(e)}), status=500, content_type="application/json")

    
def exchange_token(short_lived_token, app_id, app_secret):
    url = 'https://graph.facebook.com/v13.0/oauth/access_token'
    params = {
        'grant_type': 'fb_exchange_token',
        'client_id': app_id,
        'client_secret': app_secret,
        'fb_exchange_token': short_lived_token
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        return data.get('access_token')
    else:
        print("Failed to exchange token:", response.json())
        return None

def create_lead(lead_data):
    try:
        #Exhange the token with facebook new access token
        app_id = frappe.db.get_single_value("Facebook Lead Integration", "app_id")
        app_secret = frappe.db.get_single_value("Facebook Lead Integration", "app_secret_id")
        short_lived_token = frappe.db.get_single_value("Facebook Lead Integration", "page_access_token")
        if not app_id or not app_secret or short_lived_token:
            frappe.log_error("Go to the Doctype: Facebook Lead Integration", 'Please complete configuration')

        long_lived_token = exchange_token(short_lived_token, app_id, app_secret)
        if not long_lived_token:
            frappe.log_error("Failed to get long-lived token", 'Failed to get long-lived token')
            return

        # Update token in the Facebook Lead Integration Doctype
        doc = frappe.get_doc("Facebook Lead Integration")
        doc.page_access_token = long_lived_token
        doc.save()

        # Extract relevant fields from the JSON
        entry = lead_data.get('entry')[0] if lead_data.get('entry') else {}
        change = entry.get('changes')[0] if entry.get('changes') else {}
        value = change.get('value') if change else {}

        # Fetching lead data from Facebook API using long-lived token
        url = f"https://graph.facebook.com/{value.get('leadgen_id')}/?access_token={long_lived_token}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
        else:
            frappe.log_error(f"Failed to fetch lead data: {response.text}", "Facebook Lead Error")
            return

        # Extract field data
        field_data = data.get('field_data', [])
        email = ""
        full_name = ""
        phone_number = ""
        city = ""
        budget = ""
        whatsapp_number = ""
        purpose_of_booking = ""

        for field in field_data:
            if field.get('name') == 'email':
                email = field.get('values', [''])[0]
            elif field.get('name') == 'full name':
                full_name = field.get('values', [''])[0]
            elif field.get('name') == 'phone_number':
                phone_number = field.get('values', [''])[0]
            elif field.get('name') == 'your_whatsapp_number_please_':
                whatsapp_number = field.get('values', [''])[0]
            elif field.get('name') == 'city':
                city = field.get('values', [''])[0]
            elif field.get('name') == 'what_is_your_estimated_budget?':
                budget = field.get('values', [''])[0]
        lead_object = {
            'doctype': 'Lead',
            'lead_name': full_name,
            'whatsapp_number': whatsapp_number,
            'mobile_no': phone_number,
            'city': city,
            'email_id': email,
            'opportunity_amount': budget,
            'status': 'Lead',
            'lead_owner': "circlemarketing883@gmail.com",
            'source': "Facebook",

        }
        frappe.log_error(lead_object, "Mapped Facebook Lead Object for our system")
        # Create the new lead document with the extracted data
        new_lead = frappe.get_doc(lead_object)
        new_lead.insert(ignore_permissions=True)
        frappe.db.commit()

    except Exception as e:
        frappe.log_error(frappe.get_traceback(), "Facebook Lead Error")