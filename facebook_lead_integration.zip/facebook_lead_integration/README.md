## Facebook Lead Integration

Automatically create and manage Facebook leads in Frappe/ERPNext with seamless integration and real-time data capture.

#### License

MIT